///////////////////////////////////////////////////////////////////////////
//    Copyright (C) 2016 Wizardry and Steamworks - License: GNU GPLv3    //
///////////////////////////////////////////////////////////////////////////
function wasCSVToArray(csv) {
    var l = [];
    var s = [];
    var m = "";
 
    do {
        var a = csv.charAt(0);
        csv = csv.slice(1, csv.length);
        if(a == ",") {
            if(s[s.length-1] != '"') {
                l.push(m);
                m = "";
                continue;
            }
            m += a;
            continue;
        }
        if(a == '"' && csv.charAt(0) == a) {
            m += a;
            csv = csv.slice(1, csv.length);
            continue;
        }
        if(a == '"') {
            if(s[s.length-1] != a) {
                s.push(a);
                continue;
            }
            s.pop();
            continue;
        }
        m += a;
    } while(csv != "");
 
    l.push(m);
 
    return l;
}

///////////////////////////////////////////////////////////////////////////
//    Copyright (C) 2016 Wizardry and Steamworks - License: GNU GPLv3    //
///////////////////////////////////////////////////////////////////////////
function wasArrayToCSV(a) {
    var csv = [];
    for(var i=0; i<a.length; ++i) {
        var cell = a[i].toString().replace('"', '""');
        if(/"\s,\r\n/.test(cell)) {
            csv[i] = '"' + cell + '"';
            continue;
        }
        csv[i] = cell;
    }
    return csv.join();
}
