/*************************************************************************/
/*    Copyright (C) 2017 Wizardry and Steamworks - License: GNU GPLv3    */
/*************************************************************************/
if(!Array.prototype.product) {
	Array.prototype.product=function(b) {
		var a = this;
		return $.map(Array(Math.max(this.length, a.length)), function(e, i) {
			var o = {};
			o[a[i]] = b[i];
			return o;
		});
	};
}
$.extend({
	product: function(a, b) {
		return $.map(Array(Math.max(this.length, a.length)), function(e, i) {
			var o = {};
			o[a[i]] = b[i];
			return o;
		});
	}
});

/*************************************************************************/
/*    Copyright (C) 2017 Wizardry and Steamworks - License: GNU GPLv3    */
/*************************************************************************/
if(!Array.prototype.stride) {
	Array.prototype.stride=function(s) {
		return this.filter(function(e, i) {
			return i % s === 0;
		});
	};
}
$.extend({
	stride: function(a, s) {
		return a.filter(function(e, i) {
			return i % s === 0;
		});
	}
});

