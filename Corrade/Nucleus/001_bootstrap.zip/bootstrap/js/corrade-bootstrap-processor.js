// Add the terms of service link loader.
$('#loginurl').change(function() {
    switch($('#loginurl').find('option:selected').text()) {
	    case 'SecondLife':
	    	$('#toslink').attr('href', 'http://www.lindenlab.com/tos');
	    	break;
	    case 'OSGrid':
	    	$('#toslink').attr('href', 'http://www.osgrid.org');
	    	break;
    	default:
    		$('#tosaccept').innerHTML('Do you accept the terms of service of the selected grid?');
    		break;
    }
});
				
$('#cfgform').submit(function(evt) {
	evt.preventDefault();
	// Set the popup details.
	$('#title').html('Creating initial configuration... Please wait...');
	// Show the popup.
	$('#popup').modal('show');
	// Serialize the form to a Javascript object.
	var form = formToObject('cfgform');
	// Set progress.
	$('#progressbar').css("width", 20 + "%").attr("aria-valuenow", 20).text(20 + "%");
	$.ajax({
		type: 'GET',
		url: '/cfg/Corrade.ini.default'
		//dataType: 'xml'
	}).done(function(data) {
		// Set progress.
		$('#progressbar').css("width", 40 + "%").attr("aria-valuenow", 40).text(40 + "%");
		
		// Get default configuration.
		var x2js = new X2JS();
		var defCfg = x2js.xml2json(data);
		
		// Set configuration properties.
		defCfg.Configuration.FirstName = form.firstname;
		defCfg.Configuration.LastName = form.lastname;
		defCfg.Configuration.Password = "$1$" + CryptoJS.MD5(form.password).toString(CryptoJS.enc.Hex);
		defCfg.Configuration.LoginURL = form.loginurl;
		// Set Nucleus prefix.
		defCfg.Configuration.NucleusServerPrefix = 'http://+:' + location.port + "/";
		// Get first sample group.
		var group = defCfg.Configuration.Groups.Group;
		// Set parameters.
		group.Name = form.groupname;
		group.Password = CryptoJS.SHA1(form.grouppassword).toString(CryptoJS.enc.Hex);
		group.UUID = form.groupuuid;
		// Set single group.
		defCfg.Configuration.Groups.Group = [ group ];
		
		// Set Grid TOS acceptance.
		defCfg.Configuration.TOSAccepted = form.tos;
		
		// Set progress.
		$('#progressbar').css("width", 60 + "%").attr("aria-valuenow", 60).text(60 + "%");
		
		// Write the configuration.
		$.ajax({
			type: 'PUT',
			url: '/cfg/Corrade.ini',
			data: x2js.json2xml_str(defCfg),
			contentType: "text/html"
		}).done(function(data) {
			// Set progress.
			$('#progressbar').css("width", 80 + "%").attr("aria-valuenow", 80).text(80 + "%");
			
			$('#cfgform').load('bootstrap/htm/bootstrap-configuration-complete.html', function() {
				$('#progressbar').css("width", 100 + "%").attr("aria-valuenow", 100).text(100 + "%");
				// Hide the popup.
				$('#popup').modal('hide');
			});
		});
		
	});
});